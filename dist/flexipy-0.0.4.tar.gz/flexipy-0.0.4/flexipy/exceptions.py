class FlexipyException(Exception):
	pass